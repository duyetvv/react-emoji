import React, { Component } from 'react';
import EmojiPicker from 'emoji-picker-react';
import JSEMOJI from 'emoji-js';

import './App.css';

const emojiReg = /:[a-z_]*:/;
const regexImg = /<img\s[^>]*?src\s*=\s*["]([^"]*?)["][^>]*?title\s*=\s*["]([^"]*?)["][^>]*?>/gi;

const findIndexNode = (child) => {
  const nodes = document.getElementById('input-comment').childNodes;

  for (let i = nodes.length - 1; i >= 0; i--) {
    if (nodes[i].isEqualNode(child) || nodes[i].isEqualNode(child.parentElement)) {
      return i;
    }
  }

  return nodes.length - 1;
}


class App extends Component {
  constructor() {
    super();

    this.state = {
      focusIdx: 0,
      text: '',
      nodeIdx: 0,
      textarr: [],
    };

    this.jsemoji = new JSEMOJI();

    this.jsemoji.img_set = 'emojione';
    this.jsemoji.img_sets.emojione.path = 'https://cdn.jsdelivr.net/emojione/assets/3.0/png/32/';
    this.jsemoji.supports_css = false;
    this.jsemoji.include_title = true;
    this.jsemoji.replace_mode = 'img';
  }

  onEmojiClick = (code, data) => {
    const { focusIdx, nodeIdx, textarr } = this.state;
    const midItem = textarr[nodeIdx];
    const stArr = textarr.slice(0, nodeIdx);
    const endArr = textarr.slice(nodeIdx + 1, textarr.length || 0);
    const isEmojiCode = emojiReg.test(midItem);
    const insertIdx = isEmojiCode ? midItem.length : focusIdx;
    const fMidItem = midItem.substring(0, insertIdx);
    const sMidItem = midItem.substring(insertIdx, midItem.length || 0);
    const midArr = [`:${data.name}:`];
    if (fMidItem) { midArr.unshift(fMidItem); }
    if (sMidItem) { midArr.push(sMidItem); }
    const arrResults = [...stArr, ...midArr, ...endArr];

    this.setState({
      text: arrResults.join(''),
      textarr: arrResults,
      nodeIdx: nodeIdx + 1,
      focusIdx: 1,
    }, () => {
      console.log('onEmojiClick', this.state);
    });
  }


  onInputComment = (evt) => {
    const nodes = evt.currentTarget.childNodes;
    const nodeLen = nodes.length;
    const endNode = nodes[nodeLen - 1];
    const nodeArr = !endNode.nodeValue.trim() ? [...nodes].splice(0, nodeLen - 1) : [...nodes];
    const textarr = [...nodeArr].map((cur) => (!cur.title ? cur.textContent.trim() : `:${cur.title}:`));
    const focusNode = window.getSelection().focusNode;
    const focusOffset = window.getSelection().focusOffset;
    const focusNodeLen = focusNode.textContent.trim().length;
    const focusIdxTmp = focusOffset <= focusNodeLen ? focusOffset : focusNodeLen;
    const focusIdx = focusIdxTmp || 1;

    this.setState({
      textarr,
      text: textarr.join(''),
      focusIdx: focusIdx,
      nodeIdx: findIndexNode(focusNode),
    }, () => {
      console.log('onInputComment after setState', this.state);
    });
  }

  onKeyUpComment = () => {

    this.setState({
      focusIdx: window.getSelection().focusOffset,
      nodeIdx: findIndexNode(window.getSelection().focusNode),
    });
  }

  onFocusComment = () => {
    this.setState({
      focusIdx: window.getSelection().focusOffset,
      nodeIdx: findIndexNode(window.getSelection().focusNode),
    }, () => {
      this.replaceCaret(document.getElementById('input-comment'));
    });
  }

  componentDidMount() {
    const element = document.getElementById('input-comment');
    const html = this.jsemoji.replace_colons(this.state.text);
    const result = html.replace(regexImg, '<span class="emoji-span" id="" style="background-image: url($1);" title="$2">m</span>');

    element.innerHTML = result + '&nbsp;';

    const childNodes = element.childNodes;
    const nodesLen = childNodes.length;
    const target = childNodes[nodesLen - 1];
    const focusIdx = !target.nodeValue ? 1 : target.nodeValue.length;
    const textarr = [...childNodes].map((cur) => (!cur.title ? cur.textContent : `:${cur.title}:`));

    // this.setState(
    //   { focusNode: target, focusIdx, nodeIdx: nodesLen - 1, textarr },
    //   () => { this.setCaret(element, target, focusIdx); }
    // );
  }

  componentDidUpdate() {
    const element = document.getElementById('input-comment');
    const html = this.jsemoji.replace_colons(this.state.text);
    const result = html.replace(regexImg, '<span class="emoji-span" style="background-image: url($1); color: transparent;" title="$2">m</span>');

    element.innerHTML = result + '&nbsp;';
    // window.setTimeout(() => {  }, 0);
    this.replaceCaret(element);
  }

  replaceCaret = (element) => {
    const childNodes = element.childNodes;
    const { focusIdx, nodeIdx } = this.state;
    const target = childNodes[nodeIdx];

    this.setCaret(element, target, focusIdx);
  }

  setCaret = (element, target, focusIdx) => {
    const isTargetFocused = document.activeElement === element;

    if (target !== null && isTargetFocused) {
      var range = document.createRange();
      var selection = window.getSelection();

      range.setStart(target, focusIdx);
      range.collapse(true);
      selection.removeAllRanges();
      selection.addRange(range);

      if (element instanceof HTMLElement) { element.focus(); }
    }
  }

  render() {
    return (
      <div className="App">
        <div
          id="input-comment"
          style={styles.commentInput}
          suppressContentEditableWarning="true"
          contentEditable="true"
          role="textbox"
          onKeyUp={this.onInputComment}
          onClick={this.onFocusComment}
          // onKeyUp={this.onKeyUpComment}
        >
        </div>
        <EmojiPicker onEmojiClick={this.onEmojiClick} />
      </div>
    );
  }
}

export default App;

const styles = {
  commentInput: {
    width: '400px',
    minHeight: '40px',
    border: '1px solid red',
    textAlign: 'left',
    padding: '5px',
  }
}
