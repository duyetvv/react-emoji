import React, { Component } from 'react';
import EmojiPicker from 'emoji-picker-react';
import JSEMOJI from 'emoji-js';

import './App.css';

// const emojiReg = /(:[a-z_]*:)/gi;
const regexImg = /<img\s[^>]*?src\s*=\s*["]([^"]*?)["][^>]*?title\s*=\s*["]([^"]*?)["][^>]*?>/gi;

const findCurTextNode = (node, child) => {
  if (node.nodeType === Node.TEXT_NODE) return node;
  const children = node.childNodes;

  for (let i = children.length - 1; i >= 0; i--) {
    if (children[i].isEqualNode(child) && children[i].nodeType === Node.TEXT_NODE) {
      return children[i];
    }
  }

  return null;
}

const findIndexNode = (node, child) => {
  const children = node.childNodes;

  for (let i = children.length - 1; i >= 0; i--) {
    if (children[i].isEqualNode(child) && children[i].nodeType === Node.TEXT_NODE) {
      return i;
    }
  }

  return children.length - 1;
}


class App extends Component {
  constructor() {
    super();

    const proArr = ['Hello my name is Duyet ', ':smile:', ''];

    this.state = {
      focusIdx: 0,
      text: 'Hello my name is Duyet :smile: ',
      focusNode: null,
      focusNodeIdx: 0,
      textarr: proArr,
    };

    this.jsemoji = new JSEMOJI();

    this.jsemoji.img_set = 'emojione';
    this.jsemoji.img_sets.emojione.path = 'https://cdn.jsdelivr.net/emojione/assets/3.0/png/32/';
    this.jsemoji.supports_css = false;
    this.jsemoji.include_title = true;
    this.jsemoji.allow_native = false;
    this.jsemoji.replace_mode = 'img';

  }

  onEmojiClick = (code, data) => {
    const inputEle = document.getElementById('input-comment');
    const { focusIdx, focusNode, focusNodeIdx, textarr } = this.state;
    // const index = findIndexNode(inputEle, focusNode);
    // const midItem = textarr[index];
    // const stArr = textarr.slice(0, index);
    // const enArr = textarr.slice(index + 1, textarr.length || 0);
    const midItem = textarr[focusNodeIdx];
    const stArr = textarr.slice(0, focusNodeIdx);
    const enArr = textarr.slice(focusNodeIdx + 1, textarr.length || 0);
    const fMidItem = midItem.substring(0, focusIdx);
    const sMidItem = midItem.substring(focusIdx, midItem.length || 0);
    const arrResults = [...stArr, fMidItem, ` :${data.name}: `, sMidItem, ...enArr];

    console.log()

    this.setState({
      text: arrResults.join(''),
      textarr: arrResults,
      focusNode: inputEle.childNodes[focusNodeIdx],
      focusNodeIdx: focusNodeIdx + 1,
      focusIdx: focusIdx - 1,
    }, () => {
      console.log('onEmojiClick', this.state);
    });
  }


  onInputComment = (evt) => {
    const nodes = evt.currentTarget.childNodes;
    const textarr = [...nodes].map((cur) => (!cur.title ? cur.textContent : `:${cur.title}:`));
    const focusNode = window.getSelection().focusNode;

    console.log('onInputComment getSelection', window.getSelection(), window.getSelection().focusNode);
    this.setState({
      textarr,
      text: textarr.join(''),
      focusNode,
      focusIdx: window.getSelection().focusOffset,
      focusNodeIdx: findIndexNode(document.getElementById('input-comment'), focusNode),
    }, () => {
      console.log('onInputComment after setState', this.state);
    });
  }

  onKeyUpComment = () => {
    const focusNode = window.getSelection().focusNode;

    this.setState({
      focusNode,
      focusIdx: window.getSelection().focusOffset,
      focusNodeIdx: findIndexNode(document.getElementById('input-comment'), focusNode),
    });
  }

  onFocusComment = () => {
    const focusNode = window.getSelection().focusNode;

    this.setState({
      focusNode,
      focusIdx: window.getSelection().focusOffset,
      focusNodeIdx: findIndexNode(document.getElementById('input-comment'), focusNode),
    });
  }

  componentDidMount() {
    const element = document.getElementById('input-comment');
    const html = this.jsemoji.replace_colons(this.state.text);
    const result = html.replace(regexImg, '<span class="emoji-span" style="background-image: url($1);" title="$2"> </span>')

    element.innerHTML = result;

    const childNodes = element.childNodes;
    const nodesLen = childNodes.length;
    const target = childNodes[nodesLen - 1];
    const focusIdx = target.nodeValue.trim().length;

    this.setState(
      { focusNode: target, focusIdx, focusNodeIdx: nodesLen - 1 },
      () => { this.setCaret(element, target, focusIdx); }
    );
  }

  componentDidUpdate() {
    const element = document.getElementById('input-comment');
    const html = this.jsemoji.replace_colons(this.state.text);
    const result = html.replace(regexImg, '<span class="emoji-span" style="background-image: url($1);" title="$2">m</span>')

    element.innerHTML = result;
    this.replaceCaret(element);
  }

  replaceCaret = (element) => {
    const { focusIdx, focusNode } = this.state;
    const target = findCurTextNode(element, focusNode);

    this.setCaret(element, target, focusIdx);
  }

  setCaret = (element, target, focusIdx) => {
    const isTargetFocused = document.activeElement === element;

    if (target !== null && target.nodeValue !== null && isTargetFocused) {
      var range = document.createRange();
      var selection = window.getSelection();

      range.setStart(target, focusIdx);
      range.collapse(true);
      selection.removeAllRanges();
      selection.addRange(range);

      if (element instanceof HTMLElement) { element.focus(); }
    }
  }

  render() {
    return (
      <div className="App">
        <textarea style={{ display: 'none' }} id="input" onChange={this.onChange} ></textarea>
        <div
          id="input-comment"
          style={styles.commentInput}
          suppressContentEditableWarning="true"
          contentEditable="true"
          role="textbox"
          onInput={this.onInputComment}
          onClick={this.onFocusComment}
          onKeyUp={this.onKeyUpComment}
        >
        </div>
        <EmojiPicker onEmojiClick={this.onEmojiClick} />
      </div>
    );
  }
}

export default App;

const styles = {
  commentInput: {
    width: '400px',
    minHeight: '40px',
    border: '1px solid red',
    textAlign: 'left',
    padding: '5px',
  }
}
